"""
Sales Data Analysis
Run: python scripts/analyze_sales.py
Dataset: dataset/sample_sales.csv
"""
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "dataset" / "sample_sales.csv"
OUTPUT_DIR = ROOT / "outputs"
OUTPUT_DIR.mkdir(exist_ok=True)

df = pd.read_csv(DATA_PATH)
df["order_date"] = pd.to_datetime(df["order_date"], errors="coerce")
df["quantity"] = pd.to_numeric(df["quantity"], errors="coerce")
df["unit_price"] = pd.to_numeric(df["unit_price"], errors="coerce")

# Basic data-quality checks
print("Rows before cleaning:", len(df))
print("Missing values by column:\n", df.isna().sum())
df = df.drop_duplicates(subset="order_id")
df = df.dropna(subset=["order_date", "city", "category", "product", "quantity", "unit_price"])
df = df[(df["quantity"] > 0) & (df["unit_price"] >= 0)]

# Create revenue and reporting dimensions
df["revenue"] = df["quantity"] * df["unit_price"]
df["month"] = df["order_date"].dt.to_period("M").astype(str)

# KPI summary
summary = pd.DataFrame({
    "metric": ["Total orders", "Units sold", "Total revenue", "Average order value"],
    "value": [
        df["order_id"].nunique(),
        int(df["quantity"].sum()),
        round(df["revenue"].sum(), 2),
        round(df["revenue"].sum() / df["order_id"].nunique(), 2)
    ]
})
summary.to_csv(OUTPUT_DIR / "kpi_summary.csv", index=False)

# Business breakdowns
df.groupby("category", as_index=False)["revenue"].sum().sort_values(
    "revenue", ascending=False
).to_csv(OUTPUT_DIR / "revenue_by_category.csv", index=False)

df.groupby("city", as_index=False)["revenue"].sum().sort_values(
    "revenue", ascending=False
).to_csv(OUTPUT_DIR / "revenue_by_city.csv", index=False)

df.groupby("month", as_index=False)["revenue"].sum().sort_values(
    "month"
).to_csv(OUTPUT_DIR / "monthly_revenue.csv", index=False)

df.to_csv(OUTPUT_DIR / "cleaned_sales.csv", index=False)

print("\nKPI SUMMARY")
print(summary.to_string(index=False))
print("\nRevenue by category")
print(pd.read_csv(OUTPUT_DIR / "revenue_by_category.csv").to_string(index=False))
print(f"\nAnalysis complete. Results saved in: {OUTPUT_DIR}")
