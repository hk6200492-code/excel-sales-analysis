# Sales Data Analysis using Python

A beginner-to-intermediate portfolio project that analyses a small, **synthetic** retail sales dataset. It demonstrates data loading, quality checks, cleaning, calculated revenue, KPI reporting, and business breakdowns using Python and Pandas.

> **Dataset note:** All records are fictional and created for practice. They do not represent a real company or customer.

## Business questions
1. What is the total revenue and number of orders?
2. Which product category generates the most revenue?
3. Which city contributes the most revenue?
4. How does revenue change month by month?
5. What is the average order value?

## Tools
- Python
- Pandas
- CSV
- Git and GitHub

## Repository structure
```text
excel-sales-analysis/
├── dataset/
│   └── sample_sales.csv
├── scripts/
│   └── analyze_sales.py
├── images/
├── outputs/                 # generated when the script runs
├── README.md
└── requirements.txt
```

## Run locally
1. Install Python 3.10 or later.
2. Clone this repository or download the ZIP.
3. Open a terminal in the project folder.
4. Install dependencies:
   ```bash
   python -m pip install -r requirements.txt
   ```
5. Run the analysis:
   ```bash
   python scripts/analyze_sales.py
   ```

The script creates an `outputs/` folder containing KPI and breakdown CSV files.

## Analysis workflow
1. Load the CSV dataset with Pandas.
2. Inspect missing values and remove duplicate order IDs.
3. Remove rows with missing required fields or invalid quantities/prices.
4. Calculate revenue as `quantity × unit_price`.
5. Summarise revenue by category, city, and month.
6. Export clean data and summary tables.

## Skills demonstrated
- Reading and inspecting tabular data
- Data cleaning and validation
- Creating calculated columns
- Grouping and aggregation
- Exporting analysis results

## Next improvements
- Add charts using Matplotlib.
- Build an Excel PivotTable dashboard from the same dataset.
- Load the data into SQL and answer the same business questions.
- Add a Power BI dashboard screenshot in `images/`.

## Author
**Harish Kumar P**  
CSE – Big Data Analytics  
SRM Institute of Science and Technology, Tiruchirappalli

Connect: add your LinkedIn URL here.
