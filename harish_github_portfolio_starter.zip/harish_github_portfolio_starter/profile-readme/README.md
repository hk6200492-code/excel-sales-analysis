# Hi, I'm Harish Kumar P 👋

### CSE Big Data Analytics Student | Aspiring Data Analyst

I'm a Computer Science student specialising in Big Data Analytics at **SRM Institute of Science and Technology, Tiruchirappalli**.

I enjoy working with data, exploring datasets, writing SQL queries, and turning analysis into clear business insights.

## 🧰 Skills & Tools
- **Programming:** Python, C, Java
- **Data Analysis:** Pandas, NumPy, Exploratory Data Analysis
- **Databases:** SQL, MySQL, MongoDB
- **Business Intelligence:** Excel, Power BI
- **Big Data:** Apache Hadoop, Apache Spark, Apache Hive

## 📌 Featured Projects
- **Sales Data Analysis using Python** – data cleaning, KPIs, and revenue analysis. [View project](https://github.com/YOUR-USERNAME/excel-sales-analysis)
- **SQL Business Analysis** – coming soon
- **Power BI Sales Dashboard** – coming soon

## 🌱 Currently Learning
Advanced SQL · Python for Data Analysis · Power BI · Practical analytics projects

## 🤝 Connect
- LinkedIn: YOUR-LINKEDIN-URL
- Email: YOUR-PROFESSIONAL-EMAIL

---
*Learning continuously. Building practical projects. Turning data into insights.*
